"use strict";

function badRequest(message) {
  const error = new Error(message);
  error.code = "BAD_REQUEST";
  return error;
}

function validateChatRequest(body, allowedAgents) {
  if (!body || typeof body !== "object" || Array.isArray(body)) throw badRequest("Invalid request body");
  const agent = typeof body.agent === "string" ? body.agent.trim() : "";
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!allowedAgents.includes(agent)) throw badRequest("Unknown agent");
  if (!message) throw badRequest("Message is required");
  if (message.length > 4000) throw badRequest("Message is too long");
  return { agent, message };
}

module.exports = { validateChatRequest };
