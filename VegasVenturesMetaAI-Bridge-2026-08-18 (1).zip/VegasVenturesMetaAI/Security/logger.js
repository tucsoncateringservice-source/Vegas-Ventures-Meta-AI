"use strict";

const fs = require("node:fs/promises");
const path = require("node:path");

const logPath = path.join(__dirname, "..", "Logs", "chat_events.jsonl");

async function appendEvent(event) {
  const safeEvent = {
    timestamp: new Date().toISOString(),
    from: event.from,
    to: event.to,
    ok: Boolean(event.ok),
    durationMs: Number(event.durationMs) || 0
  };
  await fs.appendFile(logPath, `${JSON.stringify(safeEvent)}\n`, "utf8");
}

module.exports = { appendEvent };
