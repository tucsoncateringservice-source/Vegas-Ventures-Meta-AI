"use strict";

const form = document.getElementById("chat-form");
const chat = document.getElementById("chat");
const input = document.getElementById("message");
const agentSelect = document.getElementById("agent");
const status = document.getElementById("status");

function addMessage(label, text, kind) {
  const row = document.createElement("p");
  row.className = `message ${kind}`;
  const strong = document.createElement("strong");
  strong.textContent = `${label}: `;
  const content = document.createElement("span");
  content.textContent = text;
  row.append(strong, content);
  chat.append(row);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  const agent = agentSelect.value;
  if (!message) return;

  addMessage("You", message, "user");
  input.value = "";
  input.disabled = true;
  status.textContent = `Contacting ${agent}…`;

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agent, message })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    addMessage(agent, data.reply, "agent");
    status.textContent = "Connected";
  } catch (error) {
    addMessage("Bridge", error.message, "error");
    status.textContent = "Connection problem";
  } finally {
    input.disabled = false;
    input.focus();
  }
});
