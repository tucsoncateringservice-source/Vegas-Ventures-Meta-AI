"use strict";

const crypto = require("node:crypto");
const path = require("node:path");
const express = require("express");
const helmet = require("helmet");

const AgentBridge = require("../Bridge/agent_bridge");
const Archie = require("../Agents/archie");
const GateKeeper = require("../Agents/gatekeeper");
const Richard = require("../Agents/richard");
const Swarm = require("../Agents/swarm");
const { validateChatRequest } = require("../Security/validator");

const app = express();
const bridge = new AgentBridge();
const port = Number.parseInt(process.env.PORT || "5000", 10);
const host = process.env.HOST || "127.0.0.1";

bridge.register("Archie AI", new Archie());
bridge.register("GateKeeper", new GateKeeper());
bridge.register("Richard AI", new Richard());
bridge.register("Swarm Engine", new Swarm());

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "16kb", strict: true }));
app.use(express.static(path.join(__dirname)));

function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function requireBridgeToken(req, res, next) {
  const expected = process.env.BRIDGE_TOKEN;
  if (!expected) return next();
  const supplied = req.get("X-Bridge-Token") || "";
  if (!safeEqual(supplied, expected)) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  return next();
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "Vegas Ventures META AI Bridge" });
});

app.post("/chat", requireBridgeToken, async (req, res, next) => {
  try {
    const request = validateChatRequest(req.body, bridge.listAgents());
    const result = await bridge.send("User", request.agent, request.message);
    res.json(result);
  } catch (error) {
    if (error.code === "BAD_REQUEST" || error.code === "FORBIDDEN") {
      return res.status(error.code === "FORBIDDEN" ? 403 : 400).json({ error: error.message });
    }
    return next(error);
  }
});

app.use((_req, res) => res.status(404).json({ error: "Not found" }));
app.use((error, _req, res, _next) => {
  console.error(error.message);
  res.status(500).json({ error: "Bridge error" });
});

app.listen(port, host, () => {
  console.log(`Vegas Ventures Multi-Agent Chat Online at http://${host}:${port}`);
});
