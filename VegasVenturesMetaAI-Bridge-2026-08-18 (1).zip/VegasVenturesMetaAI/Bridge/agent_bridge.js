"use strict";

const permissions = require("./permissions.json");
const { appendEvent } = require("../Security/logger");

class AgentBridge {
  constructor() {
    this.agents = new Map();
  }

  register(name, agent) {
    if (!name || !agent || typeof agent.respond !== "function") {
      throw new TypeError("An agent must have a name and respond() method");
    }
    this.agents.set(name, agent);
  }

  listAgents() {
    return [...this.agents.keys()];
  }

  async send(from, to, message) {
    const allowed = permissions.routes[from] || [];
    if (!allowed.includes(to)) {
      const error = new Error("Sender is not permitted to contact that agent");
      error.code = "FORBIDDEN";
      throw error;
    }

    const agent = this.agents.get(to);
    if (!agent) {
      const error = new Error("Unknown agent");
      error.code = "BAD_REQUEST";
      throw error;
    }

    const startedAt = Date.now();
    const reply = await agent.respond({ from, message });
    await appendEvent({ from, to, ok: true, durationMs: Date.now() - startedAt });
    return { reply: String(reply), agent: to };
  }
}

module.exports = AgentBridge;
