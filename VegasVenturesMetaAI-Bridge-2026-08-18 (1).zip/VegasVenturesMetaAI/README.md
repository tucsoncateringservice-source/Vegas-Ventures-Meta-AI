# Vegas Ventures META AI Bridge

This is a safe local starter bridge for the Archie AI dashboard. It contains no API keys, passwords, or private keys.

## Start on Windows

1. Install Node.js 20 or newer.
2. Open PowerShell in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://127.0.0.1:5000` in your browser.

The starter agents return local placeholder replies. To connect Archie to a real AI model later, replace the `respond()` method in `Agents/archie.js`. Keep any provider key outside the source code.

## Security notes

- The server listens on localhost by default.
- Message size and agent names are validated.
- Replies are rendered with `textContent`, not `innerHTML`.
- Security headers are added with Helmet.
- Logs contain metadata only, not full message text.
- Set `BRIDGE_TOKEN` before exposing the service beyond your own computer.
- Use HTTPS and a proper identity system before any public deployment.
