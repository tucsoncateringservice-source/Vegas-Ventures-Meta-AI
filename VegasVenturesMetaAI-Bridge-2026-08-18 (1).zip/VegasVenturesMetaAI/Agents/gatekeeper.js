"use strict";

class GateKeeper {
  async respond() {
    return "GateKeeper is online. The request passed the local bridge checks.";
  }
}

module.exports = GateKeeper;
