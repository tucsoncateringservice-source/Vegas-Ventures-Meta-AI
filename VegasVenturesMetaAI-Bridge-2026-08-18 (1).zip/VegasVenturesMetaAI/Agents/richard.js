"use strict";

class Richard {
  async respond({ message }) {
    return `Richard AI received: ${message}`;
  }
}

module.exports = Richard;
