"use strict";

class Archie {
  async respond({ message }) {
    return `Archie bridge received your message: ${message}`;
  }
}

module.exports = Archie;
